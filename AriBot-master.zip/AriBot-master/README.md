This bot was built using the guide from Esther Crawford @EsterCrawford. 
http://lifehacker.com/how-i-turned-my-resume-into-a-chat-bot-1775565350
